#pragma once

namespace mathfunctions {
double sqrt(double x);
}
