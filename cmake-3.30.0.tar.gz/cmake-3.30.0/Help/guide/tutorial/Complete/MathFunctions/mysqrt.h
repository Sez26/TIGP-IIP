
namespace mathfunctions {
namespace detail {
double mysqrt(double x);
}
}
